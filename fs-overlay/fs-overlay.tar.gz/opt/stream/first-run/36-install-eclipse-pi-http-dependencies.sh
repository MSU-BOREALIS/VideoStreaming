#!/usr/bin/env bash

PATH=$PATH:/opt/stream/bin

cd /opt/stream/eclipse-pi-http

echo "Install npm dependencies..."
npm install
