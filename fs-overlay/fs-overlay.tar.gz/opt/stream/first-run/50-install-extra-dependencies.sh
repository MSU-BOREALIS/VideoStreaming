#!/usr/bin/env bash

echo "Installing dependencies..."
sudo apt-get -y install i2c-tools python-dev python-rpi.gpio python-smbus i2c-tools 
