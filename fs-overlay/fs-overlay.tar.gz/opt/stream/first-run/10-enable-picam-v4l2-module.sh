#!/usr/bin/env bash

echo "Adding bcm2835-v4l2 module..."
echo "bcm2835-v4l2" | sudo tee -a /etc/modules
