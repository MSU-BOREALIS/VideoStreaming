#!/usr/bin/env bash

echo "Enabling initial boot flag..."
sudo touch /etc/IS_INITIAL_BOOT
