#!/usr/bin/env bash

echo "Updating packages..."
sudo apt-get -y update

echo -e "\nUpgrading packages..."
sudo apt-get -y upgrade dist-upgrade
