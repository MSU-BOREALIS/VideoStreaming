#!/usr/bin/env bash

echo "Installing dependencies..."
sudo apt-get -y install bash-completion build-essential dnsutils git htop iperf tmux v4l-utils vim vlc
